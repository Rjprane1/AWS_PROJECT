package com.infosys.infytel.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.infytel.user.entity.cart;

public interface CartRepository extends JpaRepository <cart, Integer> {}


