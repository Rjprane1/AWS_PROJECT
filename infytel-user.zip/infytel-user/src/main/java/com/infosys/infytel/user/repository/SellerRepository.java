package com.infosys.infytel.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.infytel.user.entity.buyer;
import com.infosys.infytel.user.entity.seller;

public interface SellerRepository extends JpaRepository <seller, Integer>{

	buyer findByEmailAndPassword(String email, String password);

}
