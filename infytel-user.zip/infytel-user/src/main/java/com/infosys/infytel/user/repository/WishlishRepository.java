package com.infosys.infytel.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.infosys.infytel.user.entity.wishlist;

public interface WishlishRepository extends JpaRepository<wishlist, Integer> {

}
