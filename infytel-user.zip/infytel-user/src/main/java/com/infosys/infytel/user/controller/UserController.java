package com.infosys.infytel.user.controller;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infytel.user.entity.buyer;
import com.infosys.infytel.user.entity.cart;
import com.infosys.infytel.user.entity.seller;
import com.infosys.infytel.user.entity.wishlist;
import com.infosys.infytel.user.repository.BuyerRepository;
import com.infosys.infytel.user.service.UserService;

@RestController
@CrossOrigin
public class UserController {

	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	UserService userService;
	
	@Autowired
	BuyerRepository buyerRepository;
	
	    @PostMapping("/login")
	    public String login(@ModelAttribute("user") buyer user ) {
	    
	     buyer oauthUser = userService.login(user.getEmail(), user.getPassword());
	    
	 
	     System.out.print(oauthUser);
	     if(Objects.nonNull(oauthUser))
	     {
	  
	     return "login successfull";
	    
	    
	     } else {
	    	
	     return "Login Successfull";
	    
	    
	     }
	 
	}
	
	    @PostMapping("/logout")
	    public String logoutDo(HttpServletRequest request,HttpServletResponse response)
	    {
	        return "Login Again";
	    }
	
	

	@GetMapping("/buyer")
	public List<buyer> getAllbuyer(){
		return userService.getAllbuyer();
	}
	
	  @GetMapping("/buyer/{buyerid}")
	    public Optional<buyer> getOneBuyer(@PathVariable Integer buyerid) {
	    return	userService.getOneBuyer(buyerid);
	    }
	    @GetMapping("/seller/{sellerid}")
	    public Optional<seller> getOneSeller(@PathVariable Integer sellerid) {
	    return	userService.getOneSeller(sellerid);
	    }
	@GetMapping("/seller")
	public List<seller> getAllSeller(){
		return userService.getAllseller();
	}

	
	 @PostMapping("/buyerRegistor")
	    public String putallproducts( @Valid @RequestBody  buyer Product){

		 userService.putallproducts(Product);
		 return "register_success";
	    	
	    }
	 
	 @PostMapping("/additems")
	    public String putcartitems( @Valid @RequestBody  cart items){
		 userService.putcartitems(items);
		 return "product add to cart successfully";
	    	
	    }
	 
	 @PostMapping("/additemsWishlist")
	    public String putwishlistitems( @Valid @RequestBody  wishlist packs){
		 userService.putwishlistitems(packs);
		 return "product add to wishlist successfully";
	    	
	    }
	 
	 @DeleteMapping("/cartremove/{buyerid}")
	 public String removecartitems(@PathVariable Integer buyerid) {
		 
		 userService.removecartitems(buyerid);
		return "product add to cart successfully" ;
		 
	 }
	 
	 @PostMapping("/seller")
	    public seller putallseller(@RequestBody  seller Seller){
			return userService.putallseller(Seller);
	    
	    }
	 @GetMapping("/cart/{buyerid}")
	    public Optional<cart> getonecart(@PathVariable Integer buyerid){
			return userService.getonecart(buyerid);
	    	
	    }
	    @GetMapping("/wishlish/{buyerid}")
	    public Optional<wishlist> getonewishlist(@PathVariable Integer buyerid){
			return userService.getonewishlist(buyerid);
	    	
	    }
	   
	
	 
}
