package com.infosys.infytel.product.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.infytel.product.entity.subsprod;

public interface SubsprodRepository extends JpaRepository <subsprod , Integer> {

}
